websites = [
    'http://www.weain.mil.cn/cgxq/',
    'http://www.weain.mil.cn/cggg/zbgg/',
    'http://www.weain.mil.cn/cgcms/Xqdj/JpptContentSearchByCondition?SiteID=122&ID=15154&CatalogInner=001302',
    'http://www.weain.mil.cn/tyzb/'
]

website_base = 'http://www.weain.mil.cn'

email_address = 'ricardotian@163.com'
email_sender = 'ricardotian@163.com'
email_password = '自己填一下'
email_host = 'smtp.163.com'

words = [
    '实验室'
]
