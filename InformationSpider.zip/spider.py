import requests
from bs4 import BeautifulSoup
import config
import time
from email.mime.text import MIMEText
from email.header import Header
import os
import json

cache_file = 'cache.txt'
got_article_data = set()
if os.path.exists(cache_file):
    with open(cache_file) as f:
        t = json.load(f)
        for i in t:
            got_article_data.add(i)
send_data = []


def send_email():
    global send_data
    import smtplib

    with open(cache_file, 'w') as f2:
        t = []
        for i in got_article_data:
            t.append(i)
        json.dump(t, f2)
    if len(send_data) == 0:
        print("没有找到监测的内容")
        return

    sender = config.email_sender
    receivers = [config.email_address]

    text = ''
    for i in send_data:
        text += '网址：%s 中找到了以下关键词：%s\r\n' % (i[1], ', '.join(i[0]))
    message = MIMEText(text, 'plain', 'utf-8')
    message['From'] = Header("Spider<%s>" % config.email_address, 'utf-8')  # 发送者
    message['To'] = Header("Receiver<%s>" % config.email_address, 'utf-8')  # 接收者

    subject = '监控提醒'
    message['Subject'] = Header(subject, 'utf-8')

    try:
        smtpObj = smtplib.SMTP()
        smtpObj.connect(config.email_host, 25)
        smtpObj.login(config.email_sender, config.email_password)
        smtpObj.sendmail(sender, receivers, message.as_string())
        print("邮件发送成功")
    except smtplib.SMTPException:
        print("Error: 无法发送邮件")


def get_web_info():
    global got_article_data, send_data
    for website in config.websites:
        a = requests.get(website)
        a.encoding = 'utf-8'
        soup = BeautifulSoup(a.text, "html.parser")
        list_data = soup.find_all('div', class_='zl_tabList')
        if len(list_data) == 0:
            list_data = soup.find_all('div', class_='newsList_01')
            articles_list = list_data[0].find_all('a')
        else:
            articles_list = list_data[0].find_all('ul')[0].find_all('a')
        for article in articles_list:
            target_website = website + article.get('href')
            if article.get('href')[0] == '/':
                target_website = config.website_base + article.get('href')
            if target_website not in got_article_data:
                got_article_data.add(target_website)
                time.sleep(0.1)
                matched = []
                article_web = requests.get(target_website)
                article_web.encoding = 'utf-8'
                soup = BeautifulSoup(article_web.text, "html.parser")
                data = soup.find_all('div', class_='mainContent')[0].text
                for word in config.words:
                    if word in data:
                        matched.append(word)
                if len(matched) > 0:
                    send_data.append([matched, target_website])
        time.sleep(0.1)


if __name__ == '__main__':
    while True:
        send_data.clear()
        get_web_info()
        send_email()
        time.sleep(300)
